#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# ==========================================
# ⚙️ CONFIGURATION (CHANGE THESE VALUES)
# ==========================================
APP_NAME="Morph"
VERSION_STRING="1.3.0"                  # The marketing version (e.g., 1.1.0)
BUILD_NUMBER="112"                      # The integer build number (e.g., 110)

# Path to your built .app file (adjust based on your Xcode archive export path)
ARCHIVE_PATH="/Users/yassinbensalem/Library/Developer/Xcode/DerivedData/Morph-gstwykspykvnwebyrsybwclsxykc/Build/Products/Debug/Morph.app"

# Directory where the final zip and release files will be stored locally
OUTPUT_DIR="./releases"
ZIP_NAME="${APP_NAME}-${VERSION_STRING}.zip"
ZIP_PATH="${OUTPUT_DIR}/${ZIP_NAME}"

# Path to Sparkle's sign_update binary in your project or extracted tools folder
SIGN_TOOL="./bin/sign_update"

# Your server URLs where you plan to host the files
DOWNLOAD_URL="https://getmorph.shop/downloads/${ZIP_NAME}"
# ==========================================

echo "🚀 Starting release build for ${APP_NAME} v${VERSION_STRING} (Build ${BUILD_NUMBER})..."

# 1. Create output directory if it doesn't exist
mkdir -p "${OUTPUT_DIR}"

# 2. Check if the app build exists
if [ ! -d "${ARCHIVE_PATH}" ]; then
    echo "❌ Error: App bundle not found at ${ARCHIVE_PATH}"
    echo "Please build your app in Release mode first."
    exit 1
fi

# 3. Compress the app bundle into a clean Sparkle-compatible zip
echo "📦 Creating zip archive..."
ditto -c -k --sequesterRsrc --keepParent "${ARCHIVE_PATH}" "${ZIP_PATH}"

# 4. Get exact file size in bytes
FILE_SIZE=$(stat -f%z "${ZIP_PATH}")
echo "📏 Archive size: ${FILE_SIZE} bytes"

# 5. Generate Sparkle EdDSA cryptographic signature
if [ ! -f "${SIGN_TOOL}" ]; then
    echo "❌ Error: Sparkle sign_update tool not found at ${SIGN_TOOL}"
    exit 1
fi

echo "🔐 Generating EdDSA signature..."
SIGNATURE_OUTPUT=$("$SIGN_TOOL" "$ZIP_PATH")
echo ""
echo "--------------------------------------------------"
echo "✨ COPY THIS SIGNATURE LINE FOR YOUR appcast.xml:"
echo "$SIGNATURE_OUTPUT"
echo "--------------------------------------------------"
echo ""
echo "🎉 Build package ready at: ${ZIP_PATH}"
